// (☞ﾟ∀ﾟ)☞ static31
if( window._cgen ) {
if( !_cgen_custom.cookies_disable ) _cgen_custom.cookies_disable = 1;
}
