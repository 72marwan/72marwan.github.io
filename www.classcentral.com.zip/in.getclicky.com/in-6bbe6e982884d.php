// (☞ﾟ∀ﾟ)☞ static33
if( window._cgen ) {
if( !_cgen_custom.cookies_disable ) _cgen_custom.cookies_disable = 1;
}
