// (☞ﾟ∀ﾟ)☞ static34
if( window._cgen ) {
if( !_cgen_custom.cookies_disable ) _cgen_custom.cookies_disable = 1;
_cgen.advanced();
_cgen.ping_start();
_heatmaps_g2g_100717247='yes';
}
